﻿Console.WriteLine("Saida de dados: Usando sequencia de escapes");
Console.WriteLine();

string local = "c:\\dados\\poesias.txt";
string frase = "Ele falou:\"Não Fui Eu\"";

string pizza = "\nPizza\nde\nMussarela";
string bolo = "\nBolo\tde\tChocolate";

Console.WriteLine(pizza);
Console.WriteLine(bolo);

Console.ReadKey();