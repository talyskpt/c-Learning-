﻿Console.WriteLine("Declarando variáveis numéricas");
Console.WriteLine();
// declarando variáveis
byte v1 = 255;
sbyte v2 = -127;
int v3 = -2147483647;
uint v4 = 2147483647;
long v5 = -21474836489;
const int v6 = 999;
int v7 = 8, v8 = 9, v9 = 10;

Console.WriteLine(v1);
Console.WriteLine(v2);
Console.WriteLine(v3);
Console.WriteLine(v4);
Console.WriteLine(v5);
Console.WriteLine(v6);
Console.WriteLine(v7);
Console.WriteLine(v8);
Console.WriteLine(v9);

Console.ReadLine();