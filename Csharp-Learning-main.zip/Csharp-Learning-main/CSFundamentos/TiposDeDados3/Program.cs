﻿Console.WriteLine("Atribuindo valores para bool e char");

bool ativo = true;
System.Boolean inativo = false;

Console.WriteLine(ativo);
Console.WriteLine(inativo);

Console.WriteLine(10 == 15);
Console.WriteLine(10 == 10);

int x = 15;
int y = 10;
Console.WriteLine(x > y);

char letra1 = 'a';
char letra2 = '\u0041';

Console.WriteLine(letra1);
Console.WriteLine(letra2);

Console.ReadLine();



