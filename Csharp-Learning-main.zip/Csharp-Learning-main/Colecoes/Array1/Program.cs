﻿//declaracao do array

int[] numeros;

//alocando memoria
numeros = new int[10] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

string[] nomes = new string[5] { "teste", "teste2", "teste3", "teste4", "teste5" };
string[] nomes1 = new string[5] { "teste", "teste2", "teste3", "teste4", "teste5" };
string[] nomes2 = new string[5] { "teste", "teste2", "teste3", "teste4", "teste5" };


Console.WriteLine(nomes[0]);
Console.WriteLine(nomes[1]);
Console.WriteLine(nomes[2]);
Console.WriteLine(nomes[3]);
Console.WriteLine(nomes[4]);
Console.WriteLine(nomes[5]);

int[] numeros1;


numeros1 = new int[3];

numeros1[0] = 1;
numeros1[1] = 2;
numeros1[2] = 3;


Console.ReadKey(); 