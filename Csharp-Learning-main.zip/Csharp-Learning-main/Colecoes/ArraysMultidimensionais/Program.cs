﻿//Metodos de declaracao

int[,] a;

a = new int[2, 2]{ { 0, 1 }, { 2, 3 } };

Console.WriteLine(a[0,0]);
Console.WriteLine(a[0,1]);
Console.WriteLine(a[1,0]);
Console.WriteLine(a[1,1]);

Console.ReadKey();


int[,] b = new int[2, 2] { { 20, 30 }, { 40, 50 } };

Console.WriteLine(b[0, 0]);
Console.WriteLine(b[0, 1]);
Console.WriteLine(b[1, 0]);
Console.WriteLine(b[1, 1]);

int[,] c = { { 100, 110 }, { 120, 150 } };

/* Codigo */