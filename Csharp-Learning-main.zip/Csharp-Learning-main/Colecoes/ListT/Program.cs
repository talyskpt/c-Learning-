﻿//declaracao de uma colecao list<T>
List<string> lista;
lista = new List<string>();

List<int> lista2 = new List<int>();

var lista3 = new List<float>();

List<double> lista4 = new();


List<string> nomes = new List<string>();

nomes.Add("Joao");
nomes.Add("Paulo");

var lista5 = new List<string>()
{
    "Jonas", "Marcos", "Julio"
};

Console.ReadKey();